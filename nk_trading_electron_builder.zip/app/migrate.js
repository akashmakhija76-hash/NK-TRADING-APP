const db = require('./db');
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');
async function migrate(){
  db.exec(`
  CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, email TEXT UNIQUE, password_hash TEXT, role TEXT);
  CREATE TABLE IF NOT EXISTS products (id TEXT PRIMARY KEY, name TEXT, sku TEXT, hsn TEXT, unit TEXT, cost_price REAL, sale_price REAL, tax_percent REAL, stock_qty REAL, reorder_level REAL);
  CREATE TABLE IF NOT EXISTS invoices (id TEXT PRIMARY KEY, invoice_no TEXT, customer_id TEXT, subtotal REAL, tax_total REAL, total REAL, status TEXT, created_at TEXT);
  `);
  const count = db.prepare('SELECT COUNT(*) as c FROM users').get().c;
  if(count===0){
    const id = uuidv4();
    const pw = await bcrypt.hash('admin123',10);
    db.prepare('INSERT INTO users(id,email,password_hash,role) VALUES(?,?,?,?)').run(id,'owner@nk.com',pw,'owner');
    console.log('Created default user: owner@nk.com / admin123');
  }
  const pcount = db.prepare('SELECT COUNT(*) as c FROM products').get().c;
  if(pcount===0){
    const ins = db.prepare('INSERT INTO products(id,name,sku,hsn,unit,cost_price,sale_price,tax_percent,stock_qty,reorder_level) VALUES(?,?,?,?,?,?,?,?,?,?)');
    ins.run('p1','Kaju 320','KAJ320','0801','kg',1800,2200,18,50,5);
    ins.run('p2','Almond California','ALM32','0802','kg',1200,1500,18,30,5);
    ins.run('p3','Roasted Peanuts','PEA01','2008','kg',80,120,5,100,10);
    console.log('Seeded sample products');
  }
}
migrate().then(()=>console.log('Migration done')).catch(e=>console.error(e));
