const Database = require('better-sqlite3');
const db = new Database('nk_trading.db');
module.exports = db;
