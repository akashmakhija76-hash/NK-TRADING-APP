const express = require('express');
const path = require('path');
const { spawn } = require('child_process');
const db = require('./db');
const bodyParser = require('express').json;
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');
const app = express();
app.use(bodyParser());
app.use(express.static(path.join(__dirname,'../renderer')));

// Simple auth (owner@nk.com / admin123 seeded by migrate script)
app.post('/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if(!user) return res.status(401).send({error:'Invalid'});
  const ok = await bcrypt.compare(password, user.password_hash);
  if(!ok) return res.status(401).send({error:'Invalid'});
  const token = jwt.sign({ sub: user.id, role: user.role }, process.env.JWT_SECRET || 'change_me', { expiresIn: '7d' });
  res.send({ token, user: { id: user.id, email: user.email, role: user.role } });
});

// Simple product and invoice endpoints (same as earlier)
app.get('/api/products', (req,res)=>{
  const rows = db.prepare('SELECT * FROM products').all();
  res.send(rows);
});
app.post('/api/invoices', (req,res)=>{
  const inv = req.body;
  const id = uuidv4();
  let subtotal=0, tax_total=0;
  for(const it of inv.items){
    const amount = (it.rate*it.qty) - (it.discount||0);
    const tax = amount * (it.tax_percent||0)/100;
    subtotal += amount; tax_total += tax;
  }
  const total = subtotal + tax_total;
  db.prepare('INSERT INTO invoices(id,invoice_no,customer_id,subtotal,tax_total,total,status,created_at) VALUES(?,?,?,?,?,?,?,?)')
    .run(id, inv.invoice_no || ('NK-'+new Date().getFullYear()+'-'+Math.floor(Math.random()*9000+1000)), inv.customer_id||null, subtotal, tax_total, total, 'paid', new Date().toISOString());
  res.status(201).send({ invoice_id:id, subtotal, tax_total, total });
});

// Serve renderer (frontend)
app.get('/', (req,res)=>{
  res.sendFile(path.join(__dirname,'../renderer/index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('App listening on', PORT));
